<template>

</template>

<script>
    export default {
        name: "Resume"
    }
</script>

<style scoped>

</style>
