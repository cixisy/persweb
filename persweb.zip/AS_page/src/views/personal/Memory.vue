<template>

</template>

<script>
    export default {
        name: "Memory"
    }
</script>

<style scoped>

</style>
