<template>

</template>

<script>
    export default {
        name: "Guitar"
    }
</script>

<style scoped>

</style>
