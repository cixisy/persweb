<template>

</template>

<script>
    export default {
        name: "Games"
    }
</script>

<style scoped>

</style>
