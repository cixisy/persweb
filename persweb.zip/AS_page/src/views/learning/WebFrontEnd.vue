<template>

</template>

<script>
    export default {
        name: "WebFrontEnd"
    }
</script>

<style scoped>

</style>
