<template>

</template>

<script>
    export default {
        name: "Java"
    }
</script>

<style scoped>

</style>
